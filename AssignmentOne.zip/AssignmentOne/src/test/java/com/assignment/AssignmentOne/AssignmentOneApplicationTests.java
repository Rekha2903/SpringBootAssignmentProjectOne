package com.assignment.AssignmentOne;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssignmentOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
